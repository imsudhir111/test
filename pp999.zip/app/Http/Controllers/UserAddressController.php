<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Useraddress;
use App\Models\Statemaster;
use App\Models\Districtmaster;
use Illuminate\Support\Facades\DB;

class UserAddressController extends Controller
{
    //
    public function user_update(Request $request){
    //  return $request;
      $mapped_array=array_combine($request->name,$request->district);
      foreach ($mapped_array as $key => $value) {
        $status[]=Useraddress::where(['id'=>$key])->update(['districtmaster_id'=>$value]);
      }
      if(sizeof($status) == sizeof($request->name)){
      $notification = array(
        'message' => 'User data updated successfully',
        'alert-type' => 'success'
    );
    }else{
      $notification = array(
        'message' => 'Something went wrong',
        'alert-type' => 'success'
    );
    }
      return redirect()->route('user')->with($notification);
    }
    public function user(){ 
        $user_info['user'] = Useraddress::with('statemaster')->get();
        $user_info['states']=Statemaster::All();
        $user_info['district']=Districtmaster::All();
         
        return view('user.pages.user', $user_info);
    }

    function getdistrict(Request $request){
        $state_id= $request->state_id;
        $district=Districtmaster::where('statemaster_id', $state_id)->get();
        $html='<option value="">select city</option>';
          foreach ($district as $list){
            $html.='<option value="'.$list->id.'">'.$list->DistrictName.'</option>';
          }
          echo $html;
     }
}
