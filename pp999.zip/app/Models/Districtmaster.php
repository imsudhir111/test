<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Districtmaster extends Model
{
    use HasFactory;
    protected $guarded = [];
    public function statemaster(){
        // return $this->belongsTo('services');
            return $this->belongsTo(statemaster::class,'statemaster_id','id');
    }
}
