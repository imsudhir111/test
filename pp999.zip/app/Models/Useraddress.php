<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Useraddress extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function districtmaster(){
        // return $this->belongsTo('services');
            return $this->belongsTo(districtmaster::class,'districtmaster_id','id');
        } 
    public function statemaster(){
            // return $this->belongsTo('services');
                return $this->belongsTo(statemaster::class,'statemaster_id','id');
        }
}
