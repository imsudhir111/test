function district_filter_handler($this,sr_no){ 
    var satate_id = $("#state").val();
console.log($this.value,sr_no);
     $.ajax({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
      url: '/user/getdistrict',
      type :'post',
      delay : 200,
      data:'state_id='+$this.value,
        success:function(result){
          console.log(result);
        //   $('#district_list').html(result);
          $('#district_list'+sr_no).html(result);
        }
        
     })
    }
