 
    @include('user.layouts.header')
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper container">
 
  @yield('content')

  <!-- /.content-wrapper -->
  @include('user.layouts.footer')
  @yield('script')
</body>
</html>

