<?php

use Illuminate\Support\Facades\Route;
// use App\Http\Controllers\UserDataController;
use App\Http\Controllers\UserAddressController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/', function () {
    return redirect('user');
});
Route::get('/user', [UserAddressController::class, 'user'])->name('user');
Route::post('user/getdistrict', [UserAddressController::class, 'getdistrict'])->name('user.getdistrict');
Route::get('user/update', [UserAddressController::class, 'user_update'])->name('user.user_update');

 
