

<?php $__env->startSection('content'); ?>
<h2>USER DATA</h2>
<table class="table table-hover">
 <thead> 
   <tr>
     <th>Sr. no</th>
     <th>User Name</th>
     <th>State</th>
     <th>District</th>
   </tr>
 </thead>
 <form role="form" id="userListForm" action="<?php echo e(route('user.user_update')); ?>" method="GET"
  enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  
<tbody>
  <?php $sr_no=1; ?>
  <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($sr_no++); ?></td>
    <td><input type="hidden" name="name[]" value="<?php echo e($user_list->id); ?>" readonly /> <?php echo e($user_list->UserName); ?> </td>
    <td>
    <select class="form-control" name="state[]"  onchange="district_filter_handler(this,<?php echo e($sr_no); ?>)">
    <option>select state</option>
    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $states_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($states_list->id); ?>" <?php echo e($user_list->districtmaster->statemaster_id == $states_list->id ? 'selected':''); ?>><?php echo e($states_list->StateName); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </td> 
    <td>
      <select class="form-control" name="district[]" id="district_list<?php echo e($sr_no); ?>">
        <option>select district</option>
        <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        
         <option value="<?php echo e($district_list->id); ?>" <?php echo e($user_list->districtmaster->id == $district_list->id ? 'selected':''); ?> ><?php echo e($district_list->DistrictName); ?></option>
        
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



  
  
  </tbody>
   <input type="submit" value="update">

 </form>
</table>
</div>
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pp999\resources\views/user/pages/user.blade.php ENDPATH**/ ?>